package demo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/mytunesdb";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void initializeDatabase() {
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            // Create Songs table
            String createSongsTable = "CREATE TABLE IF NOT EXISTS songs (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "title VARCHAR(255) NOT NULL," +
                    "artist VARCHAR(255) NOT NULL," +
                    "album VARCHAR(255) NOT NULL," +
                    "year INT NOT NULL," +
                    "genre VARCHAR(100) NOT NULL," +
                    "comment TEXT," +
                    "filepath VARCHAR(500) NOT NULL)";
            stmt.execute(createSongsTable);

            // Create Playlists table
            String createPlaylistsTable = "CREATE TABLE IF NOT EXISTS playlists (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "name VARCHAR(255) NOT NULL UNIQUE)";
            stmt.execute(createPlaylistsTable);

            // Create PlaylistSongs table (join table)
            String createPlaylistSongsTable = "CREATE TABLE IF NOT EXISTS playlist_songs (" +
                    "playlist_id INT," +
                    "song_id INT," +
                    "PRIMARY KEY (playlist_id, song_id)," +
                    "FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE," +
                    "FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE)";
            stmt.execute(createPlaylistSongsTable);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Song> getAllSongs() {
        List<Song> songs = new ArrayList<>();
        String sql = "SELECT * FROM songs";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                songs.add(new Song(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("artist"),
                        rs.getString("album"),
                        rs.getInt("year"),
                        rs.getString("genre"),
                        rs.getString("comment"),
                        rs.getString("filepath")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return songs;
    }

    public static int addSong(Song song) {
        String sql = "INSERT INTO songs (title, artist, album, year, genre, comment, filepath) VALUES (?, ?, ?, ?, ?, ?, ?)";
        int generatedId = -1; // Default value if insertion fails

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            // Set parameters for the insert
            pstmt.setString(1, song.getTitle());
            pstmt.setString(2, song.getArtist());
            pstmt.setString(3, song.getAlbum());
            pstmt.setInt(4, song.getYear());
            pstmt.setString(5, song.getGenre());
            pstmt.setString(6, song.getComment());
            pstmt.setString(7, song.getFilepath());

            // Execute the insert statement
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Inserting song failed, no rows affected.");
            }

            // Retrieve the generated keys
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    generatedId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Inserting song failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return generatedId;
    }

    public static void deleteSong(int id) {
        String sql = "DELETE FROM songs WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateSongComment(int id, String newComment) {
        String sql = "UPDATE songs SET comment = ? WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newComment);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to create a new playlist
    public static int createPlaylist(String name) {
        String sql = "INSERT INTO playlists (name) VALUES (?)";
        int generatedId = -1; // Default value if insertion fails

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, name);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating playlist failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    generatedId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating playlist failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return generatedId;
    }

    // Method to add a song to a playlist
    public static void addSongToPlaylist(int playlistId, int songId) {
        String sql = "INSERT INTO playlist_songs (playlist_id, song_id) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, playlistId);
            pstmt.setInt(2, songId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to remove a song from a playlist
    public static void removeSongFromPlaylist(int playlistId, int songId) {
        String sql = "DELETE FROM playlist_songs WHERE playlist_id = ? AND song_id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, playlistId);
            pstmt.setInt(2, songId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to get songs from a playlist
    public static List<Song> getSongsFromPlaylist(String playlistName) {
        List<Song> songs = new ArrayList<>();
        String sql = "SELECT s.* FROM songs s " +
                     "JOIN playlist_songs ps ON s.id = ps.song_id " +
                     "JOIN playlists p ON ps.playlist_id = p.id " +
                     "WHERE p.name = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, playlistName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                songs.add(new Song(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("artist"),
                        rs.getString("album"),
                        rs.getInt("year"),
                        rs.getString("genre"),
                        rs.getString("comment"),
                        rs.getString("filepath")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return songs;
    }

    public static List<Playlist> getAllPlaylists() {
        List<Playlist> playlists = new ArrayList<>();
        String sql = "SELECT * FROM playlists";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                playlists.add(new Playlist(
                        rs.getInt("id"),
                        rs.getString("name")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return playlists;
    }

    public static boolean isSongInPlaylist(int playlistId, int songId) {
        String sql = "SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = ? AND song_id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, playlistId);
            pstmt.setInt(2, songId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void deletePlaylist(int playlistId) {
        try (Connection conn = connect();
             PreparedStatement pstmt1 = conn.prepareStatement("DELETE FROM playlist_songs WHERE playlist_id = ?");
             PreparedStatement pstmt2 = conn.prepareStatement("DELETE FROM playlists WHERE id = ?")) {
            pstmt1.setInt(1, playlistId);
            pstmt1.executeUpdate();
            pstmt2.setInt(1, playlistId);
            pstmt2.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static Song getSongByFilePath(String filepath) {
        String sql = "SELECT * FROM songs WHERE filepath = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, filepath);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Song(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("artist"),
                        rs.getString("album"),
                        rs.getInt("year"),
                        rs.getString("genre"),
                        rs.getString("comment"),
                        rs.getString("filepath")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
