package demo;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseButton;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import com.mpatric.mp3agic.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;



public class MyTunes extends Application {

    private TableView<Song> table;
    private ObservableList<Song> data;
    private MediaPlayer mediaPlayer;
    private String currentFilePath;
    private boolean isPaused;
    private TreeView<String> playlistTree;
    private Slider volumeSlider;
    private Label elapsedTimeLabel;
    private Label remainingTimeLabel;
    private ProgressBar progressBar;
    
    private boolean isShuffle = false;
    private boolean isRepeat = false;
    private List<Song> recentPlayList = new ArrayList<>();
    private Song currentSong;
    private Menu playRecentMenu;

    // Declare currentPlayListName at the class level
    private String currentPlayListName;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("MyTunes");

        // Initialize the database
        Database.initializeDatabase();

        table = new TableView<>();
        data = FXCollections.observableArrayList();

        TableColumn<Song, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Song, String> artistCol = new TableColumn<>("Artist");
        artistCol.setCellValueFactory(new PropertyValueFactory<>("artist"));

        TableColumn<Song, String> albumCol = new TableColumn<>("Album");
        albumCol.setCellValueFactory(new PropertyValueFactory<>("album"));

        TableColumn<Song, Integer> yearCol = new TableColumn<>("Year");
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));

        TableColumn<Song, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));

        TableColumn<Song, String> commentCol = new TableColumn<>("Comment");
        commentCol.setCellValueFactory(new PropertyValueFactory<>("comment"));
        commentCol.setCellFactory(TextFieldTableCell.forTableColumn(new DefaultStringConverter()));
        commentCol.setOnEditCommit(event -> {
            Song song = event.getRowValue();
            song.setComment(event.getNewValue());
            Database.updateSongComment(song.getId(), event.getNewValue());
        });

        table.getColumns().addAll(titleCol, artistCol, albumCol, yearCol, genreCol, commentCol);
        
        //addColumnVisibilityToggle(table, artistCol, albumCol, yearCol, genreCol, commentCol);
        
        // Create timers and progress bar
        elapsedTimeLabel = new Label("00:00:00");
        remainingTimeLabel = new Label("00:00:00");
        progressBar = new ProgressBar(0);
        progressBar.setPrefWidth(400);
     // Enable dragging to seek through the song
        progressBar.setOnMousePressed(event -> {
            if (mediaPlayer != null) {
                double mouseX = event.getX();
                double progress = mouseX / progressBar.getWidth();
                mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(progress));
            }
        });

        progressBar.setOnMouseDragged(event -> {
            if (mediaPlayer != null) {
                double mouseX = event.getX();
                double progress = mouseX / progressBar.getWidth();
                mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(progress));
            }
        });

        HBox timerBox = new HBox(10, elapsedTimeLabel, progressBar, remainingTimeLabel);
        timerBox.setAlignment(Pos.CENTER);
        timerBox.setPadding(new Insets(10));
        
        table.setItems(data);
        table.setEditable(true);
        table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        // Ensure columns resize with the window
        table.getColumns().forEach(column -> column.prefWidthProperty().bind(table.widthProperty().divide(table.getColumns().size())));

        table.setRowFactory(tv -> {
            TableRow<Song> row = new TableRow<>();
            row.setOnDragDetected(event -> {
                System.out.println("drag detected");
                if (!row.isEmpty()) {
                    ObservableList<Song> selectedSongs = table.getSelectionModel().getSelectedItems();
                    if (selectedSongs != null && !selectedSongs.isEmpty()) {
                        Dragboard db = row.startDragAndDrop(TransferMode.COPY_OR_MOVE);
                        ClipboardContent content = new ClipboardContent();

                        // Store song IDs as a comma-separated string
                        StringBuilder songIds = new StringBuilder();
                        for (Song song : selectedSongs) {
                            if (songIds.length() > 0) {
                                songIds.append(",");
                            }
                            songIds.append(song.getId());
                        }
                        content.putString(songIds.toString());
                        db.setContent(content);

                        System.out.println("Dragging Song IDs: " + songIds); // Debug statement
                        event.consume();
                    }
                }
            });
            return row;
        });

        loadSongsFromDatabase();
        loadRecentPlayList();
        
        Button playButton = new Button("Play");
        Button stopButton = new Button("Stop");
        Button pauseButton = new Button("Pause");
        Button unpauseButton = new Button("Unpause");
        Button nextButton = new Button("Next");
        Button previousButton = new Button("Previous");

        playButton.setOnAction(e -> playSong());
        stopButton.setOnAction(e -> stopSong());
        pauseButton.setOnAction(e -> pauseSong());
        unpauseButton.setOnAction(e -> unpauseSong());
        nextButton.setOnAction(e -> nextSong(table));
        previousButton.setOnAction(e -> previousSong(table));

        HBox controlBox = new HBox(10, playButton, stopButton, pauseButton, unpauseButton, nextButton, previousButton);
        controlBox.setPadding(new Insets(10));

        // Set resizing priorities for the buttons
        HBox.setHgrow(playButton, Priority.ALWAYS);
        HBox.setHgrow(stopButton, Priority.ALWAYS);
        HBox.setHgrow(pauseButton, Priority.ALWAYS);
        HBox.setHgrow(unpauseButton, Priority.ALWAYS);
        HBox.setHgrow(nextButton, Priority.ALWAYS);
        HBox.setHgrow(previousButton, Priority.ALWAYS);

        BorderPane root = new BorderPane();
        root.setCenter(table);
        root.setBottom(controlBox);

        MenuBar menuBar = createMenuBar();
        
        // Create Controls Menu
        Menu controlsMenu = new Menu("Controls");

        // Play
        MenuItem playItem = new MenuItem("Play");
        playItem.setAccelerator(KeyCombination.keyCombination("SPACE"));
        playItem.setOnAction(e -> playSong());

        // Next
        MenuItem nextItem = new MenuItem("Next");
        nextItem.setAccelerator(KeyCombination.keyCombination("Ctrl+Right"));
        nextItem.setOnAction(e -> nextSong(table));

        // Previous
        MenuItem previousItem = new MenuItem("Previous");
        previousItem.setAccelerator(KeyCombination.keyCombination("Ctrl+Left"));
        previousItem.setOnAction(e -> previousSong(table));

        // Play Recent
        playRecentMenu = new Menu("Play Recent");
        updateRecentPlayMenu(playRecentMenu);

        // Go to Current Song
        MenuItem goToCurrentItem = new MenuItem("Go to Current Song");
        goToCurrentItem.setAccelerator(KeyCombination.keyCombination("Ctrl+L"));
        goToCurrentItem.setOnAction(e -> goToCurrentSong());

        // Increase Volume
        MenuItem increaseVolumeItem = new MenuItem("Increase Volume");
        increaseVolumeItem.setAccelerator(KeyCombination.keyCombination("Ctrl+I"));
        increaseVolumeItem.setOnAction(e -> increaseVolume());

        // Decrease Volume
        MenuItem decreaseVolumeItem = new MenuItem("Decrease Volume");
        decreaseVolumeItem.setAccelerator(KeyCombination.keyCombination("Ctrl+D"));
        decreaseVolumeItem.setOnAction(e -> decreaseVolume());

        // Shuffle
        CheckMenuItem shuffleItem = new CheckMenuItem("Shuffle");
        shuffleItem.setOnAction(e -> toggleShuffle(shuffleItem.isSelected()));

        // Repeat
        CheckMenuItem repeatItem = new CheckMenuItem("Repeat");
        repeatItem.setOnAction(e -> toggleRepeat(repeatItem.isSelected()));

        // Add items to the Controls menu
        controlsMenu.getItems().addAll(
            playItem,
            nextItem,
            previousItem,
            playRecentMenu,
            goToCurrentItem,
            new SeparatorMenuItem(),
            increaseVolumeItem,
            decreaseVolumeItem,
            new SeparatorMenuItem(),
            shuffleItem,
            repeatItem
        );
        
        // Add Controls menu to the MenuBar
        menuBar.getMenus().add(controlsMenu);
        
        VBox topContainer = new VBox(menuBar, timerBox);
        root.setTop(topContainer);

        createSidebar(root);
        enableDragAndDrop();

        setupPlaylistContextMenu();

        VBox.setVgrow(table, Priority.ALWAYS);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);

        // Set initial window size and position
        primaryStage.setWidth(Screen.getPrimary().getVisualBounds().getWidth() * 0.8);
        primaryStage.setHeight(Screen.getPrimary().getVisualBounds().getHeight() * 0.8);
        primaryStage.setX((Screen.getPrimary().getVisualBounds().getWidth() - primaryStage.getWidth()) / 2);
        primaryStage.setY((Screen.getPrimary().getVisualBounds().getHeight() - primaryStage.getHeight()) / 2);

        
        primaryStage.setOnCloseRequest(event -> {
        	System.out.println("closing");
            saveRecentPlayList();
            Platform.exit();  // Optional, ensures all application resources are cleaned up
            System.exit(0);   // Optional, forces the JVM to exit
        });
        
        primaryStage.show();
        
        if (currentFilePath != null && !currentFilePath.isEmpty()) {
            initializeMediaPlayer(elapsedTimeLabel, remainingTimeLabel, progressBar);
        }
    }
    
    // Method to update recent play menu
    private void updateRecentPlayMenu(Menu playRecentMenu) {
        playRecentMenu.getItems().clear();
        for (Song song : recentPlayList) {
            MenuItem item = new MenuItem(song.getTitle());
            item.setOnAction(e -> playRecentSong(song));
            playRecentMenu.getItems().add(item);
        }
    }
    
    private void addToRecentPlayList(Song song) {
        if (!recentPlayList.contains(song)) {
            if (recentPlayList.size() >= 10) {
                recentPlayList.remove(0); // Remove oldest if more than 10
            }
            recentPlayList.add(song);
        }
        updateRecentPlayMenu(playRecentMenu); // Update the menu with recent plays
    }
    
    // Method to play a recent song
    private void playRecentSong(Song song) {
        if (song != null) {
            // Set the currentSong and currentFilePath based on the selected recent song
            currentSong = song;
            currentFilePath = song.getFilepath();
            // Highlight the song in the table
            Platform.runLater(() -> {
                table.getSelectionModel().clearSelection();
                for (Song s : table.getItems()) {
                    if (s.getId() == song.getId()) {  // Assuming Song has a unique ID
                        table.getSelectionModel().select(s);
                        table.scrollTo(s);
                        break;
                    }
                }
            });

            // Call playSong() to start playing the song
            playSong();
        }
    }



    
    // Method to toggle shuffle mode
    private void toggleShuffle(boolean isSelected) {
        isShuffle = isSelected;
        // Implement shuffle logic
    }

    // Method to toggle repeat mode
    private void toggleRepeat(boolean isSelected) {
        isRepeat = isSelected;
        // Implement repeat logic
    }
    
    // Method to increase volume
    private void increaseVolume() {
        volumeSlider.setValue(volumeSlider.getValue() + 0.05);
    }

    // Method to decrease volume
    private void decreaseVolume() {
        volumeSlider.setValue(volumeSlider.getValue() - 0.05);
    }
    
    private void goToCurrentSong() {
        if (currentSong != null) {
            // Get the index of the currently playing song in the table
            int index = table.getItems().indexOf(currentSong);

            if (index != -1) { // Check if the song is in the table
                // Clear any existing selection
                table.getSelectionModel().clearSelection();

                // Select the current song in the table
                table.getSelectionModel().select(index);

                // Scroll the table to the selected song
                table.scrollTo(index);

                // Request focus to ensure it's highlighted visually
                table.requestFocus();
            }
        }
        // No need for else case as the currently playing song is the priority
    }



    
    private void initializeMediaPlayer(Label elapsedTimeLabel, Label remainingTimeLabel, ProgressBar progressBar) {
        // This method should be called whenever a new song is played
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }

        
        mediaPlayer = new MediaPlayer(new Media(new File(currentFilePath).toURI().toString()));

        mediaPlayer.setOnReady(() -> {
            double songDuration = mediaPlayer.getTotalDuration().toSeconds();
            remainingTimeLabel.setText(formatTime(songDuration));

            // Update the progress bar and timers during playback
            mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                double elapsedSeconds = newValue.toSeconds();
                double remainingSeconds = songDuration - elapsedSeconds;

                elapsedTimeLabel.setText(formatTime(elapsedSeconds));
                remainingTimeLabel.setText(formatTime(remainingSeconds));

                progressBar.setProgress(elapsedSeconds / songDuration);
            });

            mediaPlayer.play();
        });

        mediaPlayer.setOnEndOfMedia(() -> {
            elapsedTimeLabel.setText("00:00:00");
            remainingTimeLabel.setText("00:00:00");
            progressBar.setProgress(0);
        });
    }

    private String formatTime(double totalSeconds) {
        int hours = (int) totalSeconds / 3600;
        int minutes = (int) (totalSeconds % 3600) / 60;
        int seconds = (int) totalSeconds % 60;

        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
//    private void addColumnVisibilityToggle(TableView<Song> table, TableColumn<Song, String> artistCol, TableColumn<Song, String> albumCol, 
//    		TableColumn<Song, Integer> yearCol, TableColumn<Song, String> genreCol, TableColumn<Song, String> commentCol)
//    {
//    	System.out.println("addColumnVisibilityToggle");
//    	ContextMenu headerContextMenu = new ContextMenu();
//
//        
//        // Create check menu items for each column
//        CheckMenuItem albumColumnItem = createCheckMenuItemForColumn("Album", albumCol);
//        CheckMenuItem artistColumnItem = createCheckMenuItemForColumn("Artist", artistCol);
//        CheckMenuItem yearColumnItem = createCheckMenuItemForColumn("Year", yearCol);
//        CheckMenuItem genreColumnItem = createCheckMenuItemForColumn("Genre", genreCol);
//        CheckMenuItem commentColumnItem = createCheckMenuItemForColumn("Comment", commentCol);
//
//        // Add them to the context menu
//        headerContextMenu.getItems().addAll(albumColumnItem, artistColumnItem, yearColumnItem, genreColumnItem, commentColumnItem);
//
//        // Add an event listener to show the context menu on right-click
//        table.setOnMousePressed(event -> {
//            if (event.getButton() == MouseButton.SECONDARY) {
//            	System.out.println("right click");
//                headerContextMenu.show(table, event.getScreenX(), event.getScreenY());
//            }
//        });
//
//        // Disable showing the context menu when right-clicking inside a cell
//        table.getColumns().forEach(column -> {
//            column.setContextMenu(null);
//        });
//    }

    // Helper method to create a check menu item linked to a column
    private CheckMenuItem createCheckMenuItemForColumn(String name, TableColumn<Song, ?> column) {
        CheckMenuItem checkMenuItem = new CheckMenuItem(name);
        checkMenuItem.setSelected(column.isVisible());

        checkMenuItem.setOnAction(event -> {
            column.setVisible(checkMenuItem.isSelected());
        });

        return checkMenuItem;
    }

    private void printTree(TreeItem<String> item, String indent) {
        System.out.println(indent + item.getValue());
        for (TreeItem<String> child : item.getChildren()) {
            printTree(child, indent + "  ");
        }
    }

    private void createSidebar(BorderPane root) {
        TreeItem<String> libraryRoot = new TreeItem<>("Library");
        libraryRoot.setExpanded(true);

        TreeItem<String> playlistRoot = new TreeItem<>("Playlists");
        playlistRoot.setExpanded(false);

        playlistTree = new TreeView<>(new TreeItem<>("MyTunes"));
        playlistTree.setShowRoot(false);
        playlistTree.getRoot().getChildren().addAll(libraryRoot, playlistRoot);

        // Load playlists from the database and add to the TreeView
        loadPlaylistsFromDatabase(playlistRoot);

        TreeItem<String> root1 = playlistTree.getRoot();
        printTree(root1, "  ");

        playlistTree.setCellFactory(tv -> {
            TreeCell<String> cell = new TreeCell<>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                        setContextMenu(null);
                    } else {
                        setText(item);
                        if (getTreeItem().getParent() == playlistRoot) {
                            ContextMenu contextMenu = new ContextMenu();

                            // "Open in New Window" option
                            MenuItem openInNewWindow = new MenuItem("Open in New Window");
                            openInNewWindow.setOnAction(e -> openPlaylistInNewWindow(item));
                            contextMenu.getItems().add(openInNewWindow);

                            // "Delete Playlist" option
                            MenuItem deletePlaylist = new MenuItem("Delete Playlist");
                            deletePlaylist.setOnAction(e -> deletePlaylist(getTreeItem()));
                            contextMenu.getItems().add(deletePlaylist);

                            setContextMenu(contextMenu);
                        } else {
                            setContextMenu(null);
                        }
                    }
                }
            };
            return cell;
        });

        playlistTree.setOnMousePressed(event -> {
            System.out.println("click event :");
            TreeItem<String> selected = playlistTree.getSelectionModel().getSelectedItem();
            System.out.println("playlistTree :" + playlistTree.getRoot().getChildren());
            if (selected != null && selected.getParent() == playlistTree.getRoot().getChildren().get(1)) {
                System.out.println("inside selected playlist");
                System.out.println("get parent :" + selected.getParent());
                currentPlayListName = selected.getValue();
                loadPlaylist(currentPlayListName);
            } else if (selected != null && selected.getValue() == "Library") {
                System.out.println("inside selected Library");
                loadSongsFromDatabase();
            }
        });

        VBox sidebar = new VBox(10, playlistTree);
        sidebar.setPadding(new Insets(10));
        sidebar.setPrefWidth(100); // Adjust width as needed

        volumeSlider = new Slider(0, 1, 0.5);
        volumeSlider.setShowTickMarks(true);
        volumeSlider.setShowTickLabels(true);
        volumeSlider.setMajorTickUnit(0.25);
        volumeSlider.setMinorTickCount(4);
        volumeSlider.setBlockIncrement(0.1);
        volumeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            setVolume(newValue.doubleValue());
        });

        VBox sidebarContainer = new VBox(10, sidebar, new Label("Volume"), volumeSlider);
        sidebarContainer.setPadding(new Insets(10));

        root.setLeft(sidebarContainer);
    }

    private void setVolume(double value) {
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(value);
        }
    }

    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();

        Menu fileMenu = new Menu("File");
        MenuItem openMenuItem = new MenuItem("Open");
        openMenuItem.setOnAction(e -> openSong());
        MenuItem createPlaylistMenuItem = new MenuItem("Create Playlist");
        createPlaylistMenuItem.setOnAction(e -> createPlaylist());
        MenuItem exitMenuItem = new MenuItem("Exit");
        exitMenuItem.setOnAction(e -> System.exit(0));
        fileMenu.getItems().addAll(openMenuItem, createPlaylistMenuItem, exitMenuItem);

        Menu manageMenu = new Menu("Manage");
        MenuItem addMenuItem = new MenuItem("Add Song");
        addMenuItem.setOnAction(e -> addSong());
        MenuItem deleteMenuItem = new MenuItem("Delete Song");
        deleteMenuItem.setOnAction(e -> deleteSong());
        manageMenu.getItems().addAll(addMenuItem, deleteMenuItem);

        menuBar.getMenus().addAll(fileMenu, manageMenu);

        return menuBar;
    }

    private void enableDragAndDrop() {
        table.setOnDragOver(event -> {
            if (event.getGestureSource() != table && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });

        table.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasFiles()) {
                success = true;
                for (File file : db.getFiles()) {
                    if (file.getName().endsWith(".mp3")) {
                        addSongFromFile(file, currentPlayListName);
                    }
                }
            }
            event.setDropCompleted(success);
            event.consume();
        });

        playlistTree.setOnDragOver(event -> {
            if (event.getGestureSource() != playlistTree && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });

        playlistTree.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasFiles()) {
                TreeItem<String> selectedItem = playlistTree.getSelectionModel().getSelectedItem();
                if (selectedItem != null && playListVsID.containsKey(selectedItem.getValue())) {
                    success = true;
                    for (File file : db.getFiles()) {
                        if (file.getName().endsWith(".mp3")) {
                            addSongFromFile(file, selectedItem.getValue());
                        }
                    }
                }
            }
            event.setDropCompleted(success);
            event.consume();
        });
    }

    private void addSongFromFile(File file, String playlistName) {
        try {
            Mp3File mp3file = new Mp3File(file);
            if (mp3file.hasId3v2Tag()) {
                ID3v2 id3v2Tag = mp3file.getId3v2Tag();
                Song existingSong = Database.getSongByFilePath(file.getAbsolutePath());

                if (existingSong == null) {
                    Song newSong = new Song(
                            id3v2Tag.getTitle(),
                            id3v2Tag.getArtist(),
                            id3v2Tag.getAlbum(),
                            Integer.parseInt(id3v2Tag.getYear()),
                            id3v2Tag.getGenreDescription(),
                            id3v2Tag.getComment(),
                            file.getAbsolutePath()
                    );
                    int retId = Database.addSong(newSong);
                    newSong.setId(retId);
                    data.add(newSong);
                    existingSong = newSong; // Use the newly added song
                }

                // Add to playlist regardless of whether it's a duplicate
                if (playlistName != null && !playlistName.isEmpty()) {
                    Database.addSongToPlaylist(playListVsID.get(playlistName), existingSong.getId());
                }
            }
        } catch (IOException | UnsupportedTagException | InvalidDataException e) {
            e.printStackTrace();
        }
    }

    private void addSong() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP3 Files", "*.mp3"));
        List<File> selectedFiles = fileChooser.showOpenMultipleDialog(null);
        if (selectedFiles != null) {
            for (File file : selectedFiles) {
                addSongFromFile(file, currentPlayListName);
            }
        }
    }

    private void deleteSong() {
        Song selectedSong = table.getSelectionModel().getSelectedItem();
        if (selectedSong != null) {
            data.remove(selectedSong);
            Database.deleteSong(selectedSong.getId());
            stopSong();
        }
    }

    private void openSong() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP3 Files", "*.mp3"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            currentFilePath = selectedFile.getAbsolutePath();
            playSong();
        }
    }

//    private void playSong() {
//    	
//    	 Song selectedSong = table.getSelectionModel().getSelectedItem();
//    	    
//	    if (selectedSong != null) {
//	        currentSong = selectedSong; // Set the selected song as the current song
//	        currentFilePath = currentSong.getFilepath(); // Ensure currentFilePath is set to the selected song's path
//	    }
//    	
//        if (currentFilePath != null) {
//            if (mediaPlayer != null) {
//                mediaPlayer.stop();
//            }
//            Media media = new Media(new File(currentFilePath).toURI().toString());
//            mediaPlayer = new MediaPlayer(media);
//            
//            mediaPlayer.setOnReady(() -> {
//                double songDuration = mediaPlayer.getTotalDuration().toSeconds();
//                remainingTimeLabel.setText(formatTime(songDuration));
//
//                // Update progress bar and timers during playback
//                mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
//                    double elapsedSeconds = newValue.toSeconds();
//                    double remainingSeconds = songDuration - elapsedSeconds;
//
//                    elapsedTimeLabel.setText(formatTime(elapsedSeconds));
//                    remainingTimeLabel.setText(formatTime(remainingSeconds));
//
//                    progressBar.setProgress(elapsedSeconds / songDuration);
//                });
//
//                mediaPlayer.play();
//            });
//
//            mediaPlayer.setOnEndOfMedia(() -> {
//                // Reset progress bar and timers when the song ends
//                elapsedTimeLabel.setText("00:00:00");
//                remainingTimeLabel.setText("00:00:00");
//                progressBar.setProgress(0);
//            });
//            
//            mediaPlayer.setVolume(volumeSlider.getValue()); // Set initial volume
//            mediaPlayer.play();
//        }
//        addToRecentPlayList(currentSong);
//    }
    private void playSong() {
        // Check if there is a selected song in the table only if currentSong is null
        if (currentSong == null) {
            Song selectedSong = table.getSelectionModel().getSelectedItem();
            
            if (selectedSong != null) {
                currentSong = selectedSong;
                currentFilePath = currentSong.getFilepath();
            }
        }

        // If currentSong or currentFilePath is set, proceed to play the song
        if (currentSong != null && currentFilePath != null) {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            Media media = new Media(new File(currentFilePath).toURI().toString());
            mediaPlayer = new MediaPlayer(media);

            mediaPlayer.setOnReady(() -> {
                double songDuration = mediaPlayer.getTotalDuration().toSeconds();
                remainingTimeLabel.setText(formatTime(songDuration));

                // Update progress bar and timers during playback
                mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                    double elapsedSeconds = newValue.toSeconds();
                    double remainingSeconds = songDuration - elapsedSeconds;

                    elapsedTimeLabel.setText(formatTime(elapsedSeconds));
                    remainingTimeLabel.setText(formatTime(remainingSeconds));

                    progressBar.setProgress(elapsedSeconds / songDuration);
                });

                mediaPlayer.play();
            });

            mediaPlayer.setOnEndOfMedia(() -> {
                handleSongEnd(); // Handle song end with shuffle/repeat logic
            });

            mediaPlayer.setVolume(volumeSlider.getValue()); // Set initial volume
            mediaPlayer.play();
            
            addToRecentPlayList(currentSong); // Add the current song to the recent playlist
        }
    }

    private void stopSong() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
    }

    private void pauseSong() {
        if (mediaPlayer != null && mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING) {
            mediaPlayer.pause();
            isPaused = true;
        }
    }

    private void unpauseSong() {
        if (mediaPlayer != null && isPaused) {
            mediaPlayer.play();
            isPaused = false;
        }
    }

//    private void nextSong(TableView<Song> table) {
//        int currentIndex = table.getSelectionModel().getSelectedIndex();
//        if (currentIndex < table.getItems().size() - 1) {
//            table.getSelectionModel().selectNext();
//            playSong(table);
//        }
//    }
    private void nextSong(TableView<Song> table) {
        if (isShuffle) {
            // Shuffle mode is on: play a random song
            playRandomSong();
        } else {
            int currentIndex = table.getSelectionModel().getSelectedIndex();
            if (currentIndex < table.getItems().size() - 1) {
                // Clear the current selection
                table.getSelectionModel().clearSelection();
                
                // Select the next song in the list
                table.getSelectionModel().select(currentIndex + 1);
                
                // Scroll to the selected song
                table.scrollTo(currentIndex + 1);

                // Update the current song and file path
                currentSong = table.getSelectionModel().getSelectedItem();
                currentFilePath = currentSong.getFilepath();
                
                // Play the next song
                playSong();
            } else if (isRepeat && currentIndex == table.getItems().size() - 1) {
                // Repeat the last song if repeat mode is on
                playSong();
            }
        }
    }




    private void previousSong(TableView<Song> table) {
        int currentIndex = table.getSelectionModel().getSelectedIndex();
        if (currentIndex > 0) {
            // Clear the current selection
            table.getSelectionModel().clearSelection();
            
            // Select the previous song in the list
            table.getSelectionModel().select(currentIndex - 1);
            
            // Scroll to the selected song
            table.scrollTo(currentIndex - 1);

            // Update the current song and file path
            currentSong = table.getSelectionModel().getSelectedItem();
            currentFilePath = currentSong.getFilepath();
            
            // Play the previous song
            playSong();
        }
    }


    private void loadSongsFromDatabase() {
        data.clear();
        data.addAll(Database.getAllSongs());
    }

    private void loadPlaylist(String playlistName) {
        data.clear();
        data.addAll(Database.getSongsFromPlaylist(playlistName));
    }

    HashMap<String, Integer> playListVsID = new HashMap<>();

    private void loadPlaylistsFromDatabase(TreeItem<String> playlistRoot) {
        List<Playlist> playlists = Database.getAllPlaylists();
        for (Playlist playlist : playlists) {
            if (playListVsID.get(playlist.getName()) == null)
                playListVsID.put(playlist.getName(), playlist.getId());
            TreeItem<String> playlistItem = new TreeItem<>(playlist.getName());
            playlistRoot.getChildren().add(playlistItem);
        }
        updateContextMenuWithPlaylists();
    }

    private void createPlaylist() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Create Playlist");
        dialog.setHeaderText("Enter playlist name:");
        dialog.setContentText("Name:");

        dialog.showAndWait().ifPresent(name -> {
            if (!name.trim().isEmpty()) {
                int playListID = Database.createPlaylist(name);
                playListVsID.put(name, playListID);
                TreeItem<String> playlistItem = new TreeItem<>(name);
                playlistTree.getRoot().getChildren().get(1).getChildren().add(playlistItem);
                updateContextMenuWithPlaylists();
            }
        });
    }

    
    private HashMap<String, Boolean> getColumnVisibilityStates(TableView<Song> table) {
        HashMap<String, Boolean> columnVisibilityMap = new HashMap<>();
        for (TableColumn<Song, ?> column : table.getColumns()) {
            columnVisibilityMap.put(column.getText(), column.isVisible());
        }
        return columnVisibilityMap;
    }
    
    private void applyColumnVisibilityStates(TableView<Song> table, HashMap<String, Boolean> columnVisibilityStates) {
        for (TableColumn<Song, ?> column : table.getColumns()) {
            Boolean isVisible = columnVisibilityStates.get(column.getText());
            if (isVisible != null) {
                column.setVisible(isVisible);
            }
        }
    }
    
    private void openPlaylistInNewWindow(String playlistName) {
        Stage newWindow = new Stage();
        newWindow.setTitle("Playlist: " + playlistName);

        TableView<Song> newTable = new TableView<>();
        ObservableList<Song> newData = FXCollections.observableArrayList(Database.getSongsFromPlaylist(playlistName));

        // Get the column visibility states from the main table
        HashMap<String, Boolean> columnVisibilityStates = getColumnVisibilityStates(table);
        
        TableColumn<Song, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Song, String> artistCol = new TableColumn<>("Artist");
        artistCol.setCellValueFactory(new PropertyValueFactory<>("artist"));

        TableColumn<Song, String> albumCol = new TableColumn<>("Album");
        albumCol.setCellValueFactory(new PropertyValueFactory<>("album"));

        TableColumn<Song, Integer> yearCol = new TableColumn<>("Year");
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));

        TableColumn<Song, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));

        TableColumn<Song, String> commentCol = new TableColumn<>("Comment");
        commentCol.setCellValueFactory(new PropertyValueFactory<>("comment"));
        commentCol.setCellFactory(TextFieldTableCell.forTableColumn(new DefaultStringConverter()));
        commentCol.setOnEditCommit(event -> {
            Song song = event.getRowValue();
            song.setComment(event.getNewValue());
            Database.updateSongComment(song.getId(), event.getNewValue());
        });

        newTable.getColumns().addAll(titleCol, artistCol, albumCol, yearCol, genreCol, commentCol);
        newTable.setItems(newData);
        newTable.setEditable(true);
        newWindow.requestFocus();
        
     // Apply the column visibility states to the new table
        applyColumnVisibilityStates(newTable, columnVisibilityStates);

        ContextMenu newHeaderContextMenu = createHeaderContextMenu(newTable);
        newTable.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.SECONDARY) {
                if (isClickOnHeader(event, newTable)) {
                    newHeaderContextMenu.show(newTable, event.getScreenX(), event.getScreenY());
                }
            }
        });
        
        // Ensure columns resize with the window in the new window
        newTable.getColumns().forEach(column -> column.prefWidthProperty().bind(newTable.widthProperty().divide(newTable.getColumns().size())));

        // New MediaPlayer for the new window
        MediaPlayer[] mediaPlayerForNewWindow = new MediaPlayer[1];

        // Volume Slider for the new window
        Slider newVolumeSlider = new Slider(0, 1, 0.5);
        newVolumeSlider.setShowTickMarks(true);
        newVolumeSlider.setShowTickLabels(true);
        newVolumeSlider.setMajorTickUnit(0.25);
        newVolumeSlider.setMinorTickCount(4);
        newVolumeSlider.setBlockIncrement(0.1);

        // Button controls
        Button playButton = new Button("Play");
        Button stopButton = new Button("Stop");
        Button pauseButton = new Button("Pause");
        Button unpauseButton = new Button("Unpause");
        Button nextButton = new Button("Next");
        Button previousButton = new Button("Previous");

        playButton.setOnAction(e -> {
            Song selectedSong = newTable.getSelectionModel().getSelectedItem();
            if (selectedSong != null) {
                if (mediaPlayerForNewWindow[0] != null) {
                    mediaPlayerForNewWindow[0].stop();
                }
                Media media = new Media(new File(selectedSong.getFilepath()).toURI().toString());
                mediaPlayerForNewWindow[0] = new MediaPlayer(media);
                mediaPlayerForNewWindow[0].setVolume(newVolumeSlider.getValue());
                mediaPlayerForNewWindow[0].play();
            }
        });

        stopButton.setOnAction(e -> {
            if (mediaPlayerForNewWindow[0] != null) {
                mediaPlayerForNewWindow[0].stop();
            }
        });

        pauseButton.setOnAction(e -> {
            if (mediaPlayerForNewWindow[0] != null && mediaPlayerForNewWindow[0].getStatus() == MediaPlayer.Status.PLAYING) {
                mediaPlayerForNewWindow[0].pause();
            }
        });

        unpauseButton.setOnAction(e -> {
            if (mediaPlayerForNewWindow[0] != null && mediaPlayerForNewWindow[0].getStatus() == MediaPlayer.Status.PAUSED) {
                mediaPlayerForNewWindow[0].play();
            }
        });

        nextButton.setOnAction(e -> {
            int currentIndex = newTable.getSelectionModel().getSelectedIndex();
            if (currentIndex < newTable.getItems().size() - 1) {
                newTable.getSelectionModel().selectNext();
                playButton.fire(); // Simulate the play button click
            }
        });

        previousButton.setOnAction(e -> {
            int currentIndex = newTable.getSelectionModel().getSelectedIndex();
            if (currentIndex > 0) {
                newTable.getSelectionModel().selectPrevious();
                playButton.fire(); // Simulate the play button click
            }
        });

        newVolumeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (mediaPlayerForNewWindow[0] != null) {
                mediaPlayerForNewWindow[0].setVolume(newValue.doubleValue());
            }
        });

        HBox controlBox = new HBox(10, playButton, stopButton, pauseButton, unpauseButton, nextButton, previousButton);
        controlBox.setPadding(new Insets(10));

        VBox bottomBox = new VBox(10, controlBox, new Label("Volume"), newVolumeSlider);
        bottomBox.setPadding(new Insets(10));

        BorderPane newRoot = new BorderPane();
        newRoot.setCenter(newTable);
        newRoot.setBottom(bottomBox);

        VBox.setVgrow(newTable, Priority.ALWAYS);

        Scene newScene = new Scene(newRoot, 800, 600);
        newWindow.setScene(newScene);

        // Set initial window size and position for the new window
        newWindow.setWidth(Screen.getPrimary().getVisualBounds().getWidth() * 0.8);
        newWindow.setHeight(Screen.getPrimary().getVisualBounds().getHeight() * 0.8);
        newWindow.setX((Screen.getPrimary().getVisualBounds().getWidth() - newWindow.getWidth()) / 2);
        newWindow.setY((Screen.getPrimary().getVisualBounds().getHeight() - newWindow.getHeight()) / 2);

        // Add event handler for window close
        newWindow.setOnCloseRequest(event -> {
            if (mediaPlayerForNewWindow[0] != null) {
                mediaPlayerForNewWindow[0].stop();
            }
        });

        newWindow.show();

        newTable.setOnDragOver(event -> {
            if (event.getGestureSource() != newTable && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            } else if (event.getGestureSource() != newTable && event.getDragboard().hasString()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });

        newTable.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasFiles()) {
                success = true;
                for (File file : db.getFiles()) {
                    if (file.getName().endsWith(".mp3")) {
                        addSongFromFile(file, playlistName);
                        newData.clear();
                        newData.addAll(Database.getSongsFromPlaylist(playlistName));
                    }
                }
            } else if (db.hasString()) {
                String songIdStr = db.getString();
                String[] songIds = songIdStr.split(",");

                for (String songIdStr1 : songIds) {
                    int songId = Integer.parseInt(songIdStr1.trim());
                    Database.addSongToPlaylist(playListVsID.get(playlistName), songId);
                }

                // Refresh the playlist view
                newData.clear();
                newData.addAll(Database.getSongsFromPlaylist(playlistName));
                success = true;
            }
            event.setDropCompleted(success);
            event.consume();
        });

        // Refresh the main library table
        loadSongsFromDatabase();

        // Set the selection to the "Library" node
        playlistTree.getSelectionModel().select(playlistTree.getRoot().getChildren().get(0));

        // Pass the newData list to be refreshed later
        refreshablePlaylists.put(playlistName, newData);
    }

    private void playSong(TableView<Song> table) {
        Song selectedSong = table.getSelectionModel().getSelectedItem();
        if (selectedSong != null) {
        	currentSong = selectedSong;
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            Media media = new Media(new File(selectedSong.getFilepath()).toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            
            mediaPlayer.setOnReady(() -> {
                double songDuration = mediaPlayer.getTotalDuration().toSeconds();
                remainingTimeLabel.setText(formatTime(songDuration));

                // Update progress bar and timers during playback
                mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                    double elapsedSeconds = newValue.toSeconds();
                    double remainingSeconds = songDuration - elapsedSeconds;

                    elapsedTimeLabel.setText(formatTime(elapsedSeconds));
                    remainingTimeLabel.setText(formatTime(remainingSeconds));

                    progressBar.setProgress(elapsedSeconds / songDuration);
                });

                mediaPlayer.play();
            });

            mediaPlayer.setOnEndOfMedia(() -> {
                // Reset progress bar and timers when the song ends
                elapsedTimeLabel.setText("00:00:00");
                remainingTimeLabel.setText("00:00:00");
                progressBar.setProgress(0);
            });
            
            mediaPlayer.setVolume(volumeSlider.getValue()); // Set initial volume
            mediaPlayer.play();
        }
        addToRecentPlayList(currentSong);
    }

    private HashMap<String, ObservableList<Song>> refreshablePlaylists = new HashMap<>();

    private String getPlaylistNameById(int playlistId) {
        for (HashMap.Entry<String, Integer> entry : playListVsID.entrySet()) {
            if (entry.getValue() == playlistId) {
                return entry.getKey();
            }
        }
        return null;
    }

    private void addToPlaylist(int playlistId) {
        Song selectedSong = table.getSelectionModel().getSelectedItem();
        if (selectedSong != null) {
            // Add the song to the playlist regardless of whether it already exists in the playlist
            Database.addSongToPlaylist(playlistId, selectedSong.getId());

            // Since the song should be updated only once in the library, no need to check for duplicates here
            // Ensure the library is always up-to-date
            if (!data.contains(selectedSong)) {
                data.add(selectedSong);
            }

            // Check if the playlist is currently open in a new window
            String playlistName = getPlaylistNameById(playlistId);
            if (playlistName != null && refreshablePlaylists.containsKey(playlistName)) {
                ObservableList<Song> playlistSongs = refreshablePlaylists.get(playlistName);
                playlistSongs.clear();
                playlistSongs.addAll(Database.getSongsFromPlaylist(playlistName));
            }
        }
    }

    private void updateContextMenuWithPlaylists() {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem addSongMenuItem = new MenuItem("Add Song");
        MenuItem deleteSongMenuItem = new MenuItem("Delete Song");
        addSongMenuItem.setOnAction(e -> addSong());
        deleteSongMenuItem.setOnAction(e -> deleteSong());

        Menu addToPlaylistMenu = new Menu("Add to playlist");
        for (String playlistName : playListVsID.keySet()) {
            MenuItem playlistItem = new MenuItem(playlistName);
            playlistItem.setOnAction(e -> addToPlaylist(playListVsID.get(playlistName)));
            addToPlaylistMenu.getItems().add(playlistItem);
        }
        contextMenu.getItems().addAll(addSongMenuItem, deleteSongMenuItem, addToPlaylistMenu);

        // Create the header context menu
        ContextMenu headerContextMenu = createHeaderContextMenu(table);
        
        table.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY && event.getClickCount() == 1) {
                Song selectedSong = table.getSelectionModel().getSelectedItem();
                if (selectedSong != null) {
                    currentFilePath = selectedSong.getFilepath();
                }
            }
            if (event.getButton() == MouseButton.SECONDARY) {
                if (isClickOnHeader(event, table)) {
                    headerContextMenu.show(table, event.getScreenX(), event.getScreenY());
                } else {
                	headerContextMenu.hide(); 
                	contextMenu.show(table, event.getScreenX(), event.getScreenY());
                }
            }
            else {
                headerContextMenu.hide(); // Hide header context menu when clicking elsewhere
                contextMenu.hide();   // Hide cell context menu when clicking elsewhere
            }
        });
    }

    private boolean isClickOnHeader(MouseEvent event, TableView<Song> table) {
        // This checks if the event was on the header row by checking the bounds of the header row
        Node header = table.lookup(".column-header-background");
        if (header != null) {
            Bounds headerBounds = header.localToScene(header.getBoundsInLocal());
            return headerBounds.contains(event.getSceneX(), event.getSceneY());
        }
        return false;
    }

    private ContextMenu createHeaderContextMenu(TableView<Song> table) {
        ContextMenu headerContextMenu = new ContextMenu();

        // Retrieve columns by name
        TableColumn<Song, ?> albumCol = getColumnByName(table, "Album");
        TableColumn<Song, ?> artistCol = getColumnByName(table, "Artist");
        TableColumn<Song, ?> yearCol = getColumnByName(table, "Year");
        TableColumn<Song, ?> genreCol = getColumnByName(table, "Genre");
        TableColumn<Song, ?> commentCol = getColumnByName(table, "Comment");

        // Create check menu items for each column
        CheckMenuItem albumColumnItem = createCheckMenuItemForColumn("Album", albumCol);
        CheckMenuItem artistColumnItem = createCheckMenuItemForColumn("Artist", artistCol);
        CheckMenuItem yearColumnItem = createCheckMenuItemForColumn("Year", yearCol);
        CheckMenuItem genreColumnItem = createCheckMenuItemForColumn("Genre", genreCol);
        CheckMenuItem commentColumnItem = createCheckMenuItemForColumn("Comment", commentCol);

        // Add them to the header context menu
        headerContextMenu.getItems().addAll(albumColumnItem, artistColumnItem, yearColumnItem, genreColumnItem, commentColumnItem);

        return headerContextMenu;
    }
    
    private TableColumn<Song, ?> getColumnByName(TableView<Song> table, String name) {
        for (TableColumn<Song, ?> column : table.getColumns()) {
            if (column.getText().equals(name)) {
                return column;
            }
        }
        return null; // or throw an exception if not found
    }
    
    private void setupPlaylistContextMenu() {
        playlistTree.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.SECONDARY) {
                TreeItem<String> selectedItem = playlistTree.getSelectionModel().getSelectedItem();
                if (selectedItem != null && selectedItem.getParent() == playlistTree.getRoot().getChildren().get(1)) {
                    ContextMenu contextMenu = new ContextMenu();
                    MenuItem deletePlaylistMenuItem = new MenuItem("Delete Playlist");
                    deletePlaylistMenuItem.setOnAction(e -> deletePlaylist(selectedItem));
                    contextMenu.getItems().add(deletePlaylistMenuItem);
                    contextMenu.show(playlistTree, event.getScreenX(), event.getScreenY());
                }
            }
        });
    }

    private void deletePlaylist(TreeItem<String> playlistItem) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Playlist");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete the playlist: " + playlistItem.getValue() + "?");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                String playlistName = playlistItem.getValue();
                int playlistId = playListVsID.get(playlistName);
                Database.deletePlaylist(playlistId);
                playListVsID.remove(playlistName);
                playlistItem.getParent().getChildren().remove(playlistItem);
                if (playlistName.equals(currentPlayListName)) {
                    loadSongsFromDatabase();
                }
            }
        });
    }
    
 // Method to save the recent playlist to a file
    private void saveRecentPlayList() {
    	System.out.println("saveRecentPlayList");
        try (FileWriter writer = new FileWriter("recentPlaylist.json")) {
            Gson gson = new Gson();
            gson.toJson(recentPlayList, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
 // Method to load the recent playlist from a file
    private void loadRecentPlayList() {
        try {
            if (Files.exists(Paths.get("recentPlaylist.json"))) {
            	System.out.println("loadRecentPlayList");
                String content = new String(Files.readAllBytes(Paths.get("recentPlaylist.json")));
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<Song>>() {}.getType();
                recentPlayList = gson.fromJson(content, listType);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 // Method to handle song end, considering repeat and shuffle modes
    private void handleSongEnd() {
    	if (isRepeat) {
            // Repeat the current song
            playSong();
        } else if (isShuffle) {
            // Shuffle mode: Play a random song
            playRandomSong();
        } else {
            // Normal mode: Play the next song
            nextSong(table);
        }
    }

 // Method to play a random song from the playlist
    private void playRandomSong() {
        int songCount = table.getItems().size();
        if (songCount > 0) {
            int randomIndex = new Random().nextInt(songCount);

            // Highlight and select the random song in the table
            Platform.runLater(() -> {
                table.getSelectionModel().clearSelection();
                table.getSelectionModel().select(randomIndex);
                table.scrollTo(randomIndex);
            });

            // Set the current song and file path to the randomly selected song
            currentSong = table.getItems().get(randomIndex);
            currentFilePath = currentSong.getFilepath();

            // Play the selected random song
            playSong();
        }
    }

} 